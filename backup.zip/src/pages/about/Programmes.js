import React from 'react'
import Footer from '../components/Footer/Footer'
import Navigation from '../components/Navigation/Navigation'

const Programmes = () => {
    return (
        <>
        <Navigation />
        <Footer />
        </>
    )
}

export default Programmes