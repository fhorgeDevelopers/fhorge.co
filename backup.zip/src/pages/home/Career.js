const Career = () => {
    return (
        "Career"
    );
}

export default Career;