import React from 'react'

export const Career = () => {
    return (
        <div>Career</div>
    )
}
