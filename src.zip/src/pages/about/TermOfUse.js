import React from 'react'
import { Helmet } from 'react-helmet'

const TermOfUse = () => {
    return (
        <>
            <Helmet>
                <title>
                    Terms of Use | Fhorge
                </title>
            </Helmet>
        </>
    )
}

export default TermOfUse